const form = document.querySelector('form');
const projectInput = document.querySelector('#project');

// Submit Event

form.addEventListener('submit', handleEvent);


// Keyboard Events
//projectInput.addEventListener('keydown', handleEvent);
//projectInput.addEventListener('keyup', handleEvent);
//projectInput.addEventListener('keypress', handleEvent);
//projectInput.addEventListener('focus', handleEvent);
//projectInput.addEventListener('cut', handleEvent);
//projectInput.addEventListener('paste', handleEvent);


function handleEvent(e) {
  console.log(`Event type is: ${e.type}`);

  
  //e.preventDefault();
}