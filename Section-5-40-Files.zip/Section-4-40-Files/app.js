class Person {
  constructor(firstName, lastName, dob) {
    this.firstName = firstName;
    this.lastName = lastName;
    this.birthday = new Date(dob);
  }

  sayHello() {
    return `Hello there .. My name is ${this.firstName} ${this.lastName}`;
  }

  getAge() {
    const diff = Date.now() - this.birthday.getTime();
    const ageDate = new Date(diff);
    return Math.abs(ageDate.getUTCFullYear() - 1970);
  }

  getsMarried(newLastName) {
    this.lastName = newLastName;
  }

  static sayHiTo(name) {
    return `Hello ${name}!`;
  }

}

const sara = new Person('Sara', 'Haddad', '1-2-1980');

console.log(sara);
console.log(sara.sayHello());
console.log(sara.getAge());
sara.getsMarried('Naggar');
console.log(sara);
console.log(Person.sayHiTo('Rami'));

