let value;

const list = document.querySelector('ul.collection');
const listItem = document.querySelector('li.collection-item:first-child');
// Get child nodes
value = list.childNodes;
value = list.childNodes[1];
value = list.childNodes[0].nodeName;
value = list.childNodes[1].nodeType;

// Get children element nodes
value = list.children;
value = list.children[1];
value = list.children[2].textContent = "Test";
value = list.children[1].children[0].id = 'test';

// First/Last child
value = list.firstChild;
value = list.firstElementChild;
value = list.lastChild;
value = list.lastElementChild;

// Count child elements
value = list.childElementCount;

// Get parent node
value = listItem.parentNode;
value = listItem.parentElement;
value = listItem.parentElement.parentElement;

// Get next/previous sibling
value = listItem.nextSibling;
value = listItem.nextElementSibling;

value = listItem.previousSibling;
value = listItem.previousElementSibling;






console.log(value);
