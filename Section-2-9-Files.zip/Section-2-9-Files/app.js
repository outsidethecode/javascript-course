
const firstName = 'Elon';
const lastName = 'Musk';
const str = 'Hello my name is Elon';
const languages = 'Python,Java,Javascript,C#';

// Concatenation
let value = firstName + ' ' + lastName;

// Append
value = 'Elon';
value += ' Musk';

// Length 
value = firstName.length;

// concat()
value = firstName.concat(' ', lastName);

// Escaping
value = 'That\'s awesome';

// Change case
value = firstName.toUpperCase();
value = firstName.toLowerCase();

// substring()
value = firstName.substring(1, 3);

// slice()
value = firstName.slice(-2);

// slpit()
value = languages.split(',');

// indexOf 
value = firstName.indexOf('o');
value = firstName.lastIndexOf('o');

// charAt()
value = firstName.charAt(firstName.length - 1);

// replace()
value = str.replace('Elon', 'Rami');

// includes()
value = value.includes('Elon');

console.log(value);